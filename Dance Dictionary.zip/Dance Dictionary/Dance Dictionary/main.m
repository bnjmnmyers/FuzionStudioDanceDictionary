//
//  main.m
//  Dance Dictionary
//
//  Created by Benjamin Myers on 3/2/14.
//  Copyright (c) 2014 AppGuys. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DD_AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DD_AppDelegate class]));
    }
}
