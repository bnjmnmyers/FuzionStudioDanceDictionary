//
//  Term.m
//  Dance Dictionary
//
//  Created by Benjamin Myers on 3/3/14.
//  Copyright (c) 2014 AppGuys. All rights reserved.
//

#import "Term.h"


@implementation Term

@dynamic termID;
@dynamic term;
@dynamic definition;
@dynamic videoURL;
@dynamic origin;
@dynamic pronunciation;

@end
